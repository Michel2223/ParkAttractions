﻿using Park.DataAcces;
using Park.Logic;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Park
{
    internal class IsConsole
    {
        #region(Greetings)

        static public int Greetings()
        {
            Console.WriteLine("Добро пожаловать в Park Attraction!");
            string _visitorName = RecordName();
            int _visitorAge = RecordAge(_visitorName);
            
            return _visitorAge;
        }

        static private string RecordName()
        {
            string _visitorName;
            Console.WriteLine("Напишите ваше имя, пожалуйста:");
            return _visitorName = Console.ReadLine();
        }

        static private int RecordAge(string _visitorName)
        {
            int _visitorAge;
            Console.WriteLine(_visitorName + ", напишите ваш возраст, пожалуйста:");
            
            return _visitorAge = int.Parse(Console.ReadLine());
        }

        static public string CheckStudent() //узнать в какое место в бл впихнуть
        {
                Console.WriteLine("Если вы обучаетесь в высшем учебном заведении, то напишите его название ниже, если нет, то оставьте поле пустым");
                string _visitorStudent = Console.ReadLine();
                
            return _visitorStudent;
        }

        #endregion


        #region(BuyOrInfo)

        static public int BuyOrInfo()
        {
            Console.WriteLine();
            Console.Write("Выберите действие: \n" +
                              "1 Показать информацию об аттракционах\n" +
                              "2 Купить билет\n" +
                              "Ваш выбор: ");
            int _visitorChoiceBuyOrInfo = int.Parse(Console.ReadLine());
            return _visitorChoiceBuyOrInfo;
        }

        static public void BuyTicket(string pathFile1)
        {
            TicketInfo(pathFile1);
            Console.Write("Выберите необходимый билет: ");
        }

        #region(Info)

        static public void AttractionsInfo(string pathFile, string pathFile1)
        {
            using (StreamReader reader = new StreamReader(pathFile))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
            UserInteraction.Launch(pathFile, pathFile1);
        }

        static private void TicketInfo(string pathFile1)
        {
            using (StreamReader reader = new StreamReader(pathFile1))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
        }

        #endregion

        #endregion

        #region(SelectedAttraction)

        static public string SelectedAttraction(List<string> message)
        {
            PrintMessageAttraction();
            PrintMessage(message);
            return PrintAttraction(message);
        }

        static private void PrintMessageAttraction()
        {
            Console.WriteLine();
            Console.WriteLine("Какой аттракцион вы желаете посетить?\n" +
                              "Напишите сопутствующий ему номер");
        }

        static private string PrintAttraction(List<string> message)
        {
            int Id = int.Parse(Console.ReadLine());
            Check.ID = Id;
            Check.NameAttract = message[Id - 1];
            Check.Price = SortAttractions.GetPriceAttraction();
            return message[Id - 1];
        }

        #endregion



        #region(VisitorSelectedAttraction)

        static public void VisitorSelectedAttraction()
        {
            IssuingACheck();
        }

        #endregion 

        #region(VisitorSelectedAllInclusive)

        static public void VisitorSelectedAllInclusive()
        {
            IssuingACheck();
        }

        #endregion  

        #region(VisitorSelectedStudent)

        static public void VisitorSelectedStudent()
        {
            IssuingACheck();
        }


        #endregion  


        #region (SelectedTime)

        static public int SelectedTime(List<string> freeTime)
        {
            PrintMessageTime(freeTime);
            return ReadLineTime(freeTime);
        }

        static private void PrintMessageTime(List<string> freeTime)
        {
            Console.WriteLine("Выберите свободное время аттракциона");
            foreach (var time in freeTime)
            {
                Console.WriteLine(time);
            }
        }

        static private int ReadLineTime(List<string> freeTime)
        {
            var message = Console.ReadLine();

            bool isStringInList = CheckIfStringInList(freeTime, message);

            while (!isStringInList)
            {
                PrintErrorMessage();
                message = Console.ReadLine();
                isStringInList = CheckIfStringInList(freeTime, message);
            }
            Check.Time = Convert.ToInt32(message);
            return int.Parse(message);
        }

        #endregion


        #region(Завершение(ЧЕК))

        static private void IssuingACheck()
        {
            Console.WriteLine();
            Console.WriteLine( "ЧЕК" );
            Console.WriteLine( "Билет: " + Check.NameTicket );
            if ( Check.NameAttract != null ) { Console.WriteLine( "Ваш аттракцион: " + Check.NameAttract ); }
            if (Check.NameAttract != null) { Console.WriteLine("Время: " + Check.Time); }
            Console.WriteLine( "Стоимость: " + Check.Price );
            if ( Check.Discount != 0 ) Console.WriteLine( "Скидка: " + Check.Discount );
            Console.WriteLine( "К оплате: " + (Check.Price - Check.Discount) );
            Console.WriteLine();
        }

        #endregion


        #region (Invariants)

        static private bool CheckIfStringInList(List<string> list, string searchTerm)
        {
            return list.Any(s => s == searchTerm);
        }

        static private void PrintErrorMessage()
        {
            Console.WriteLine("Вы ввели неправильное сообщение!");
            Console.WriteLine("Введите заново");
        }

        #endregion.

        #region PrintMessage

        static private void PrintMessage(List<string> message)
        {
            for (int i = 0; i < message.Count; i++)
            {
                Console.WriteLine($"{i + 1}) {message[i]}");
            }
        }

        #endregion 
    }
}
