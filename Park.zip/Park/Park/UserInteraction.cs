﻿using Microsoft.Win32;
using Park.DataAcces;
using Park.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Park
{
    public class UserInteraction
    {
        List<Attraction> _allAttracts;
        static private Registration _registration;

        public UserInteraction(string pathFile, string pathFile1)
        {
            GenerateAttracts(pathFile);
            InitInterface();
            while (true)
            {
                Beginning();
                Launch(pathFile, pathFile1);
            }
        }

        private void GenerateAttracts(string pathFile)
        {
            IGenerator generator = new Generator(pathFile);
            _allAttracts = generator.GenerateAttracts();
        }

        private void InitInterface()
        {
            _registration = new Registration(_allAttracts);
        }

        static public void Launch(string pathFile, string pathFile1)
        {
            int _visitorChoiceBuyOrInfo = IsConsole.BuyOrInfo();        // Получили выбор клиента (информация или покупка)
            IsAction(pathFile, pathFile1, _visitorChoiceBuyOrInfo);     // Предоставление информации/билетов
            int choicedTicketNumber = ChoicedTicket();                  // Выбор билета

            if (choicedTicketNumber == 1)
            {
                List<string> freeTime = _registration.GetFreeTime();    // Получили свободное время аттракциона
                int choicedTime = IsConsole.SelectedTime(freeTime);     // Выбрали время записи

                Record record = new Record(choicedTime);                // Запись на основе данных с консоли
                _registration.AddRecord(record);                        // Передаем запись в БизнесЛогику

                IsConsole.VisitorSelectedAttraction();                  // Печатаем ЧЕК
            }
        }

        static public void Beginning()
        {
            int _visitorAge = IsConsole.Greetings();
            CheckAgeForStudent(_visitorAge);
        }

        static private void CheckAgeForStudent(int _visitorAge)
        {
            if (_visitorAge >= 16)
            {
                IsConsole.CheckStudent();
            }
        }

        static private void IsAction(string pathFile, string pathFile1, int _visitorChoiceBuyOrInfo)
        {
            if      (_visitorChoiceBuyOrInfo == 1)    { IsConsole.AttractionsInfo(pathFile, pathFile1); }
            else if (_visitorChoiceBuyOrInfo == 2)    { IsConsole.BuyTicket(pathFile1); }
        }

        static private int ChoicedTicket()
        {
            int _visitorChoiceTicket = int.Parse(Console.ReadLine());

            if (_visitorChoiceTicket == 1)   { Check.NameTicket =      "Разовый"; /*Check.Price = SortAttractions.GetPriceAttraction();*/ IsConsole.SelectedAttraction(_registration.AllAttractions); }
            if (_visitorChoiceTicket == 2)   { Check.NameTicket = "Всё включено"; Check.Price = 2500;                        IsConsole.VisitorSelectedAllInclusive(); }
            if (_visitorChoiceTicket == 3)   { Check.NameTicket = "Студенческий"; Check.Price = 2500; Check.Discount = 1000; IsConsole.VisitorSelectedStudent(); }

            return _visitorChoiceTicket;
        }

    }
}
