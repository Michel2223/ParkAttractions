﻿using Park;

internal class Program
{
    private static void Main(string[] args)
    {
        UserInteraction userInteraction = new UserInteraction(args[0], args[1]);
    }
}
