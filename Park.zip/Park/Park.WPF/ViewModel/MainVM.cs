﻿using Park.WPF.ViewModel.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using Park.WPF.Infastructure;
using System.Collections.ObjectModel;
using System.Numerics;
using Park.WPF.View.Windows;
using Park.Logic;

namespace Park.WPF.ViewModel
{
    public class MainVM: BaseVM
    {
        #region Свойства

        private string _name;
        public string Name { get => _name; set => Set(ref _name, value); }


        private int _age;
        public int Age { get => _age; set => Set(ref _age, value); }


        private string _institution;
        public string Institution { get => _institution; set => Set(ref _institution, value); }

        #endregion

        #region Команды

        public ICommand OpenOpenTicketWindowCommand { get; }

        private bool CanOpenTicketWindowCommand(object p)
        {
            if (!string.IsNullOrEmpty(_name) && (_age >= 1 && _age <= 100))
            {
                return true;
            }
            else
            {
                return false;
            }
        } 

        private void OnOpenTicketWindowCommand(object p)
        {
            TicketVM ticketVM = new TicketVM(_name, _age, _institution);
            Ticket ticket = new Ticket(ticketVM);
            ticket.Owner = Application.Current.MainWindow;
            ticket.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ticket.ShowDialog();
        }

        #endregion


        public MainVM()
        {
            OpenOpenTicketWindowCommand = new LambdaCommand(OnOpenTicketWindowCommand, CanOpenTicketWindowCommand);
        }
    }
}
