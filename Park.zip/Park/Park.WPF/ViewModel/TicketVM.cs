﻿using Park.Logic;
using Park.WPF.ViewModel.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows;
using Park.WPF.Infastructure;
using Park.DataAcces;
using Park.WPF.Model;
using System.Windows.Shapes;

namespace Park.WPF.ViewModel
{
    public class TicketVM: BaseVM
    {
        #region Поля

        private string _name;
        private int _age;
        private string _institution;

        private List<Attraction> _allAttractions;

        #endregion

        #region Свойства

        private string _ticketReceipt;
        public string TicketReceipt { get => _ticketReceipt; set => Set(ref _ticketReceipt, value); }


        private ObservableCollection<string> _typeAttration = new ObservableCollection<string>();
        public ObservableCollection<string> TypeAttration { get => _typeAttration; set => Set(ref _typeAttration, value); }


        private string _selectedAttraction;
        public string SelectedAttraction { get => _selectedAttraction; set => Set(ref _selectedAttraction, value); }

        #endregion

        #region Команды

        #region Разовый билет

        public ICommand BuyOnetimeTicketCommand { get; }

        private bool CanBuyOnetimeTicketCommand(object p)
        {
            if (SelectedAttraction == null)
            {
                return false;
            }
            if (string.IsNullOrEmpty(_selectedAttraction))
            {
                return false;
            }
            return true;
        }

        private void OnBuyOnetimeTicketCommand(object p)
        {
            Check.NameTicket = "Разовый";
            string[] nameAndPrise = _selectedAttraction.Split('-');
            Check.NameAttract = nameAndPrise[0];
            Check.Price = int.Parse(nameAndPrise[1]);
            if (!string.IsNullOrEmpty(_institution))
            {
                Check.Discount = 100;
            }
            CreateTicketReceiptOnetime();
        }

        private void CreateTicketReceiptOnetime()
        {
            TicketReceipt = $"ЧЕК\n" +
                            $"Билет: {Check.NameTicket}\n" +
                            $"Ваш аттракцион: {Check.NameAttract}\n" +
                            $"Стоимость: {Check.Price}\n" +
                            $"Скидка: {Check.Discount}\n" +
                            $"К оплате: {Check.Price - Check.Discount}";
        }

        #endregion

        #region Все включено билет

        public ICommand BuyAllTicketCommand { get; }

        private bool CanBuyAllTicketCommand(object p) => true;

        private void OnBuyAllTicketCommand(object p)
        {
            Check.NameTicket = "Все включено";
            Check.Price = 2500;
            if (!string.IsNullOrEmpty(_institution))
            {
                Check.Discount = 100;
            }
            CreateTicketReceiptAll();
        }

        private void CreateTicketReceiptAll()
        {
            TicketReceipt = $"ЧЕК\n" +
                            $"Билет: {Check.NameTicket}\n" +
                            $"Стоимость: {Check.Price}\n" +
                            $"Скидка: {Check.Discount}\n" +
                            $"К оплате: {Check.Price - Check.Discount}";
        }

        #endregion

        #region Студенческий билет

        public ICommand BuyStudentTicketCommand { get; }

        private bool CanBuyStudentTicketCommand(object p) 
        {
            if (string.IsNullOrEmpty(_institution))
            {
                return false;
            }
            return true;
        }

        private void OnBuyStudentTicketCommand(object p)
        {
            Check.NameTicket = "Студенческий";
            Check.Price = 1500;
            CreateTicketReceiptStudent();
        }

        private void CreateTicketReceiptStudent()
        {
            TicketReceipt = $"ЧЕК\n" +
                            $"Билет: {Check.NameTicket}\n" +
                            $"Стоимость: {Check.Price}\n" +
                            $"К оплате: {Check.Price - Check.Discount}";
        }

        #endregion

        #endregion


        public TicketVM(string name, int age, string institution)
        {
            _name = name;
            _age = age;
            _institution = institution;

            BuyOnetimeTicketCommand = new LambdaCommand(OnBuyOnetimeTicketCommand, CanBuyOnetimeTicketCommand);
            BuyAllTicketCommand = new LambdaCommand(OnBuyAllTicketCommand, CanBuyAllTicketCommand);
            BuyStudentTicketCommand = new LambdaCommand(OnBuyStudentTicketCommand, CanBuyStudentTicketCommand);
            GenerateAttraction();
            InitItemInComboBox();
        }

        private void GenerateAttraction()
        {
            IGenerator iGenerator = new Generator(@"C:\Users\Михаил\Desktop\Predmets\TechnoProg\HUH\Park\Park\Park.DataAcces\Data\Attractions.txt");
            _allAttractions = iGenerator.GenerateAttracts();
        }

        private void InitItemInComboBox()
        {
            foreach (var attraction in _allAttractions)
            {
                AttractionPrise attractionPrise = new AttractionPrise(attraction.Name, attraction.Price);
                _typeAttration.Add(attractionPrise.NameAndPrise);
            }
        }

    }
}
