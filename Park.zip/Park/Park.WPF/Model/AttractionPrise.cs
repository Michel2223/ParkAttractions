﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Park.WPF.Model
{
    public class AttractionPrise
    {
        public string Name { get; set; }
        public int Prise { get; set; }

        public string NameAndPrise { get => Name + "-" + Prise.ToString(); }

        public AttractionPrise(string name, int prise)
        {
            Name = name;
            Prise = prise;
        }
    }
}
