﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Park.Logic
{
    public class Attraction
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int LimitFrom { get; set; }

        public int LimitBefore { get; set; }

        public int Price { get; set; }
        
        public Schedule Schedule { get; set; }

        public Attraction(int id, string name, int limitFrom, int limitBefore, int price)
        {
            Id = id;
            Name = name;
            LimitFrom = limitFrom;
            LimitBefore = limitBefore;
            Price = price;
            Schedule = new Schedule();
        }
    }
}
