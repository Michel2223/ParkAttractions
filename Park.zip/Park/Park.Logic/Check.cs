﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Park.Logic
{
    public class Check
    {
        static public string NameTicket { get; set; }

        static public string NameAttract { get; set; }

        static public int ID { get; set; }

        static public int Price { get; set; }

        static public int Discount { get; set; }

        static public int Time { get; set; }

        public Schedule Schedule { get; set; }

        public Check(string nameTicket, string nameAttract, int id, int price, int discount, int time)
        {
            NameTicket = nameTicket;
            NameAttract = nameAttract;
            ID = id;
            Price = price;
            Discount = discount;
            Time = time;
            Schedule = new Schedule();
        }
    }
}
