﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Park.Logic
{
    public class Schedule
    {
        public Dictionary<int, Record> Clock = new Dictionary<int, Record>()
        {
            { 8, null},
            { 9, null},
            { 10, null},
            { 11, null},
            { 12, null},
            { 13, null},
            { 14, null},
            { 15, null},
            { 16, null},
            { 17, null},
            { 18, null},
            { 19, null},
            { 20, null},
        };
    }
}
