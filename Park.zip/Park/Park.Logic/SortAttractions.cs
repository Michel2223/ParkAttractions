﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Park.Logic
{
    static public class SortAttractions
    {
        static public List<string> GetName(List<Attraction> attracts)
        {
            return attracts
                   .Select(d => d.Name)
                   .ToList();
        }

        static public List<int> GetPrice(List<Attraction> attracts)
        {
            return attracts
                   .Select(d => d.Price)
                   .ToList();
        }

        static public void GetNameAndPrice()
        {
            List<string> name = GetName(new List<Attraction>());
            List<int> price = GetPrice(new List<Attraction>());
            Dictionary<string, int> nameAndPrice = new Dictionary<string, int>();
            foreach (int i in price)
            {
                nameAndPrice.Add(name[i], price[i]); 
            }
            Console.WriteLine(nameAndPrice);
        }

        static public int GetPriceAttraction()
        {
            List<string> name = GetName(new List<Attraction>());
            List<int> price = GetPrice(new List<Attraction>());
            int priceAttraction = 250;
            for (int i = 1; i <= 12; i++)
            {
                if (i == Check.ID)
                {
                    return price[i+1];
                }
            }
            return GetPriceAttraction();
        }
    }
}
