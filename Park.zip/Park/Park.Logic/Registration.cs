﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Park.Logic
{
    public class Registration
    {
        public List<string> AllAttractions { get; }

        private List<Attraction> _allAttracts;

        public Registration(List<Attraction> allAttracts)
        {
            _allAttracts = allAttracts;
            AllAttractions = SortAttractions.GetName(_allAttracts);
        }

        public List<string> GetFreeTime()
        {   
            Schedule schedule = new Schedule();

            return schedule.Clock.
                  Where(x => x.Value == null).
                  Select(x => x.Key.ToString()).
                  ToList();
        }

        public void AddRecord(Record record)
        {
            Schedule schedule = new Schedule();
            schedule.Clock[record.Time] = record; // добавление записи
        }

    }
}
