﻿using Park.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Park.DataAcces
{
    public class Generator: IGenerator
    {
        private string _pathFile;

        public Generator(string pathFile)
        {
            _pathFile = pathFile;
        }

        public List<Attraction> GenerateAttracts()
        {
            List<Attraction> attracts = new List<Attraction>();
            using (StreamReader reader = new StreamReader(_pathFile))
            {
                string? line;
                while ((line = reader.ReadLine()) != null)
                {
                    List<string> options = new List<string>();
                    string[] stroke = line.Split(' ');
                    foreach (string word in stroke) options.Add(word);

                    attracts.Add(CreateAttractions(options));
                    options.Clear();
                }
            }
            return attracts;
        }

        private Attraction CreateAttractions(List<string> options)
        {
            string _name = options[1];
            int id = int.Parse(options[0]);
            int _limitFrom = int.Parse(options[2]);
            int _limitBefore = int.Parse(options[3]);
            int _price = int.Parse(options[4]);

            return new Attraction(id, _name, _limitFrom, _limitBefore, _price);
        }
    }
}
