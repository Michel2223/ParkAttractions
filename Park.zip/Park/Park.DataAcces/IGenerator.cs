﻿using Park.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Park.DataAcces
{
    public interface IGenerator
    {
        public List<Attraction> GenerateAttracts();
    }
}
